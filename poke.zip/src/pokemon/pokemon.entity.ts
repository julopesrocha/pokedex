export class Pokemon {
    id: number;
    name: string;
    sprits: {
        front_default:  string;
    };
    abilities: string;
    baseStats: string;
}